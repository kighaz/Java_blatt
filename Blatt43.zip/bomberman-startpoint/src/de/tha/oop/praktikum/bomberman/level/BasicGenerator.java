package de.tha.oop.praktikum.bomberman.level;

import de.tha.oop.praktikum.bomberman.controllers.HandOperatedController;
import de.tha.oop.praktikum.bomberman.core.GameObjectSet;
import de.tha.oop.praktikum.bomberman.gameobjects.*;
import de.tha.oop.praktikum.bomberman.util.XY;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class BasicGenerator implements LevelGenerator {

    private static final int WIDTH  = 11;
    private static final int HEIGHT = 9;
    private static final int NUM_MONSTERS         = 3;
    private static final int NUM_DESTRUCTIBLE_WALLS = 8;
    private static final int NUM_POWERUPS         = 2;

    private final Random random = new Random();

    @Override
    public XY getSize() {
        return new XY(WIDTH, HEIGHT);
    }

    @Override
    public GameObjectSet generate() {
        GameObjectSet gos = new GameObjectSet();

        // Border walls
        for (int x = 0; x < WIDTH; x++) {
            gos.addObject(new Wall(new XY(x, 0)));
            gos.addObject(new Wall(new XY(x, HEIGHT - 1)));
        }
        for (int y = 1; y < HEIGHT - 1; y++) {
            gos.addObject(new Wall(new XY(0, y)));
            gos.addObject(new Wall(new XY(WIDTH - 1, y)));
        }

        // Collect free inner cells
        List<XY> freeCells = new ArrayList<>();
        for (int x = 1; x < WIDTH - 1; x++) {
            for (int y = 1; y < HEIGHT - 1; y++) {
                freeCells.add(new XY(x, y));
            }
        }
        Collections.shuffle(freeCells, random);

        int idx = 0;

        // Destructible walls
        for (int i = 0; i < NUM_DESTRUCTIBLE_WALLS && idx < freeCells.size(); i++, idx++) {
            gos.addObject(new DestructibleWall(freeCells.get(idx)));
        }

        // Monsters
        for (int i = 0; i < NUM_MONSTERS && idx < freeCells.size(); i++, idx++) {
            gos.addObject(new Monster(freeCells.get(idx)));
        }

        // PowerUps
        for (int i = 0; i < NUM_POWERUPS && idx < freeCells.size(); i++, idx++) {
            gos.addObject(new PowerUp(freeCells.get(idx)));
        }

        return gos;
    }

    @Override
    public Bomberman addPlayer(GameObjectSet gos) {
        // Place player at (1,1) — always free after border walls
        Bomberman player = new Bomberman(new HandOperatedController(), new XY(1, 1));
        gos.addObject(player);
        return player;
    }
}
