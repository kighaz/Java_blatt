package de.tha.oop.praktikum.bomberman.container;

public abstract class AbstractContainer implements Container {

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Container)) return false;
        Container other = (Container) o;
        if (this.size() != other.size()) return false;
        for (int i = 0; i < size(); i++) {
            if (!get(i).equals(other.get(i))) return false;
        }
        return true;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Container content:\n");
        for (int i = 0; i < size(); i++) {
            sb.append("Element ").append(i).append(": ").append(get(i)).append("\n");
        }
        return sb.toString();
    }
}
