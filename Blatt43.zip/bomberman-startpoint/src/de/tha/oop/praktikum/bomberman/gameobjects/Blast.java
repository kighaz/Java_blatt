package de.tha.oop.praktikum.bomberman.gameobjects;

import de.tha.oop.praktikum.bomberman.controllers.GameObjectController;
import de.tha.oop.praktikum.bomberman.controllers.StandStillController;
import de.tha.oop.praktikum.bomberman.core.BoardView;
import de.tha.oop.praktikum.bomberman.util.MoveCommand;
import de.tha.oop.praktikum.bomberman.util.XY;

public class Blast extends AbstractGameObject {

    public static final int DEFAULT_POINTS = 300;
    public static final int LIFETIME = 3;

    private int roundsLeft;
    private final Bomberman owner;

    public Blast(GameObjectController controller, XY location) {
        super(controller, location);
        this.roundsLeft = LIFETIME;
        this.owner = null;
    }

    public Blast(XY location) {
        super(new StandStillController(), location);
        this.roundsLeft = LIFETIME;
        this.owner = null;
    }

    public Blast(XY location, Bomberman owner) {
        super(new StandStillController(), location);
        this.roundsLeft = LIFETIME;
        this.owner = owner;
    }

    public Bomberman getOwner() { return owner; }

    @Override
    protected int getDefaultPoints() { return DEFAULT_POINTS; }

    public int getRoundsLeft() { return roundsLeft; }

    /**
     * Returns true when the blast should be removed.
     * LIFETIME=3 means the blast is visible for 2 full turns after creation (ticked 3 times total).
     */
    public boolean tick() {
        roundsLeft--;
        return roundsLeft <= 0;
    }

    @Override
    public MoveCommand nextStep(BoardView view) {
        return MoveCommand.NONE;
    }
}