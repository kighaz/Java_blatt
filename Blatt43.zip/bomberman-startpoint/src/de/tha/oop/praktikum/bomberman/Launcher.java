package de.tha.oop.praktikum.bomberman;

import de.tha.oop.praktikum.bomberman.core.*;
import de.tha.oop.praktikum.bomberman.level.BasicGenerator;
import de.tha.oop.praktikum.bomberman.level.LevelGenerator;
import de.tha.oop.praktikum.bomberman.ui.ConsoleUI;
import de.tha.oop.praktikum.bomberman.ui.UI;

public class Launcher {

    public static void main(String[] args) {
        // Modularer Aufbau: LevelGenerator, UI und Game können leicht ausgetauscht werden
        LevelGenerator generator = new BasicGenerator();
        UI ui = new ConsoleUI();                        // <- hier einfach gegen GUI tauschen

        Board board = new Board(generator, true);       // true = Spieler wird erzeugt
        GameState state = new GameState(board);
        Game game = new SinglePlayerGame(state, ui);    // <- hier SinglePlayer / MultiPlayer etc.

        game.run();
       
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
}
