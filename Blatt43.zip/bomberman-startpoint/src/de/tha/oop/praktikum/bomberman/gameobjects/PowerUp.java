package de.tha.oop.praktikum.bomberman.gameobjects;

import de.tha.oop.praktikum.bomberman.controllers.GameObjectController;
import de.tha.oop.praktikum.bomberman.controllers.StandStillController;
import de.tha.oop.praktikum.bomberman.util.XY;

public class PowerUp extends AbstractGameObject {

    public static final int DEFAULT_POINTS = 50;

    public PowerUp(GameObjectController controller, XY location) {
        super(controller, location);
    }

    public PowerUp(XY location) {
        super(new StandStillController(), location);
    }

    @Override
    protected int getDefaultPoints() {
        return DEFAULT_POINTS;
    }
}
