package de.tha.oop.praktikum.bomberman.gameobjects;

import de.tha.oop.praktikum.bomberman.controllers.GameObjectController;
import de.tha.oop.praktikum.bomberman.controllers.HandOperatedController;
import de.tha.oop.praktikum.bomberman.core.BoardView;
import de.tha.oop.praktikum.bomberman.util.MoveCommand;
import de.tha.oop.praktikum.bomberman.util.XY;

public class Bomberman extends AbstractGameObject {

    public static final int DEFAULT_POINTS = 0;

    private boolean bombPending = false;
    private boolean hasBomb = true;

    public Bomberman(GameObjectController controller, XY location) {
        super(controller, location);
    }

    public Bomberman(XY location) {
        super(new HandOperatedController(), location);
    }

    @Override
    protected int getDefaultPoints() { return DEFAULT_POINTS; }

    @Override
    public GameObjectController getController() { return controller; }

    public void onBombExploded() { hasBomb = true; }

    public boolean isBombPending() { return bombPending; }

    public void clearBombPending() { bombPending = false; }

    @Override
    public MoveCommand nextStep(BoardView view) {
        MoveCommand cmd = controller.getNextMove(view);

        if (cmd == MoveCommand.BOMB) {
            if (hasBomb && !bombPending) {
                // Premier appel BOMB: marquer comme en attente, rester sur place
                bombPending = true;
                hasBomb = false;
            }
            return MoveCommand.NONE; // Reste sur place
        }

        // Mouvement: InteractionGrid posera la bombe si bombPending == true
        return cmd;
    }
}