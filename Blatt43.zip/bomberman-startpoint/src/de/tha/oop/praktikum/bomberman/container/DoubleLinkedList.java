package de.tha.oop.praktikum.bomberman.container;

import de.tha.oop.praktikum.bomberman.exceptions.ElementNotFoundException;
import de.tha.oop.praktikum.bomberman.exceptions.InvalidIndexException;

import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Random;

public class DoubleLinkedList extends AbstractContainer {

    private static class Node {
        Object data;
        Node next;
        Node prev;
        Node(Object data) { this.data = data; }
    }

    private final Node head; // Dummy-Element
    private int size;
    private int modCount = 0;

    public DoubleLinkedList() {
        head = new Node(null);
        head.next = head;
        head.prev = head;
        size = 0;
    }

    @Override
    public boolean add(Object o) {
        Node newNode = new Node(o);
        Node last = head.prev;
        last.next = newNode;
        newNode.prev = last;
        newNode.next = head;
        head.prev = newNode;
        size++;
        modCount++;
        return true;
    }

    @Override
    public Object get(int i) {
        if (i < 0 || i >= size) throw new InvalidIndexException(i, size);
        Node current = head.next;
        for (int j = 0; j < i; j++) current = current.next;
        return current.data;
    }

    @Override
    public int size() { return size; }

    @Override
    public boolean remove(Object o) {
        Node current = head.next;
        while (current != head) {
            if (current.data.equals(o)) {
                current.prev.next = current.next;
                current.next.prev = current.prev;
                size--;
                modCount++;
                return true;
            }
            current = current.next;
        }
        throw new ElementNotFoundException(o);
    }

    /** Anonyme Klasse als Iterator (Aufgabe 1c) */
    @Override
    public Iterator<Object> iterator() {
        return new Iterator<Object>() {
            private Node current = head.next;
            private final int expectedModCount = modCount;

            @Override
            public boolean hasNext() {
                return current != head;
            }

            @Override
            public Object next() {
                if (modCount != expectedModCount)
                    throw new ConcurrentModificationException();
                if (!hasNext()) throw new NoSuchElementException();
                Object data = current.data;
                current = current.next;
                return data;
            }
        };
    }

    @Override
    public Iterator<Object> iteratorRandom() {
        // Alle Elemente in Array kopieren, mischen, dann darüber iterieren
        Object[] copy = toArray();
        Random rnd = new Random();
        for (int i = copy.length - 1; i > 0; i--) {
            int j = rnd.nextInt(i + 1);
            Object tmp = copy[i]; copy[i] = copy[j]; copy[j] = tmp;
        }
        final int expectedMod = modCount;
        return new Iterator<Object>() {
            int idx = 0;
            @Override public boolean hasNext() { return idx < copy.length; }
            @Override public Object next() {
                if (modCount != expectedMod) throw new ConcurrentModificationException();
                if (!hasNext()) throw new NoSuchElementException();
                return copy[idx++];
            }
        };
    }
}