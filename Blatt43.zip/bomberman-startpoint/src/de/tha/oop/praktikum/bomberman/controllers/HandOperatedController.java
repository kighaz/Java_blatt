package de.tha.oop.praktikum.bomberman.controllers;

import de.tha.oop.praktikum.bomberman.core.BoardView;
import de.tha.oop.praktikum.bomberman.util.MoveCommand;

public class HandOperatedController implements GameObjectController {

    private MoveCommand pendingMove = MoveCommand.NONE;

    @Override
    public void setPlayerMoveCommand(MoveCommand command) {
        this.pendingMove = command;
    }

    @Override
    public MoveCommand getNextMove(BoardView view) {
        MoveCommand cmd = pendingMove;
        pendingMove = MoveCommand.NONE; // reset after use
        return cmd;
    }
}
