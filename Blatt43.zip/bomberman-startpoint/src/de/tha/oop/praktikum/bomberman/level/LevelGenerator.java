package de.tha.oop.praktikum.bomberman.level;

import de.tha.oop.praktikum.bomberman.core.GameObjectSet;
import de.tha.oop.praktikum.bomberman.gameobjects.Bomberman;
import de.tha.oop.praktikum.bomberman.util.XY;

public interface LevelGenerator {
    XY getSize();
    GameObjectSet generate();
    Bomberman addPlayer(GameObjectSet gos);
}
