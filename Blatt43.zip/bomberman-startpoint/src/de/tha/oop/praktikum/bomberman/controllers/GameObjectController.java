package de.tha.oop.praktikum.bomberman.controllers;

import de.tha.oop.praktikum.bomberman.core.BoardView;
import de.tha.oop.praktikum.bomberman.util.MoveCommand;

public interface GameObjectController {

    MoveCommand getNextMove(BoardView view);

    /**
     * Wird von der UI aufgerufen, um die Benutzereingabe an den Controller zu übergeben.
     * Default-Implementierung tut nichts (für KI-Controller).
     */
    default void setPlayerMoveCommand(MoveCommand command) {
        // default: do nothing
    }
}
