package de.tha.oop.praktikum.bomberman.controllers;

import de.tha.oop.praktikum.bomberman.core.BoardView;
import de.tha.oop.praktikum.bomberman.util.MoveCommand;

public class StandStillController implements GameObjectController {

    @Override
    public MoveCommand getNextMove(BoardView view) {
        return MoveCommand.NONE;
    }
}
