package de.tha.oop.praktikum.bomberman.core;

import de.tha.oop.praktikum.bomberman.ui.UI;

public abstract class Game {

    protected final GameState state;
    protected final UI ui;

    public Game(GameState state, UI ui) {
        this.state = state;
        this.ui = ui;
    }

    public void run() {
        while (true) {
            render();
            processInput();
            update();
        }
    }

    protected abstract void processInput();

    protected void render() {
        ui.render(state.getBoard().getInteractionGrid());
    }

    protected void update() {
        state.update();
    }
}
