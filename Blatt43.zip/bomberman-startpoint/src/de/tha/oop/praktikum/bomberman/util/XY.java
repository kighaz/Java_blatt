package de.tha.oop.praktikum.bomberman.util;

public final class XY {

    private final int x;
    private final int y;

    public XY(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    /**
     * Gibt einen neuen Punkt zurück, der um den Vektor direction verschoben ist.
     */
    public XY move(XY direction) {
        return new XY(this.x + direction.x, this.y + direction.y);
    }

    @Override
    public String toString() {
        return "(" + x + "," + y + ")";
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof XY)) return false;
        XY other = (XY) obj;
        return this.x == other.x && this.y == other.y;
    }

    @Override
    public int hashCode() {
        return 31 * x + y;
    }
}
