package de.tha.oop.praktikum.bomberman.ui;

import de.tha.oop.praktikum.bomberman.core.BoardView;
import de.tha.oop.praktikum.bomberman.util.MoveCommand;

public interface UI {
    MoveCommand getCommand();
    void render(BoardView view);
}
