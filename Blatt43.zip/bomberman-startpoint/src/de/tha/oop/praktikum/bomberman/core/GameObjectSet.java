package de.tha.oop.praktikum.bomberman.core;

import de.tha.oop.praktikum.bomberman.container.Container;
import de.tha.oop.praktikum.bomberman.container.Vector;
import de.tha.oop.praktikum.bomberman.exceptions.ElementNotFoundException;
import de.tha.oop.praktikum.bomberman.gameobjects.GameObject;

import java.util.Iterator;

public class GameObjectSet {

    private final Container objects;
    // Snapshot de la liste au début du tour pour itération sûre
    private GameObject[] turnSnapshot;
    private int snapshotIndex;

    public GameObjectSet() {
        this.objects = new Vector();
    }

    public void addObject(GameObject obj) {
        objects.add(obj);
    }

    public void removeObject(GameObject obj) {
        try {
            objects.remove(obj);
        } catch (ElementNotFoundException e) {
            // already removed – ignore
        }
    }

    public boolean contains(GameObject obj) {
        return objects.contains(obj);
    }

    public int size() {
        return objects.size();
    }

    public GameObject get(int i) {
        return (GameObject) objects.get(i);
    }

    /**
     * Prépare le tour: fait un snapshot dans un ordre aléatoire (Aufgabe 1f).
     * Le snapshot évite ConcurrentModificationException si des objets sont
     * ajoutés/supprimés pendant le tour.
     */
    public void startTurn() {
        int n = objects.size();
        turnSnapshot = new GameObject[n];
        // Utilise iteratorRandom pour ordre aléatoire
        Iterator<Object> it = objects.iteratorRandom();
        int i = 0;
        while (it.hasNext()) {
            turnSnapshot[i++] = (GameObject) it.next();
        }
        snapshotIndex = 0;
    }

    /** Fin du tour. */
    public void endTurn() {
        turnSnapshot = null;
    }

    /**
     * Retourne le prochain GameObject du tour ou null si tous ont joué.
     */
    public GameObject getNextGameObject() {
        if (turnSnapshot == null || snapshotIndex >= turnSnapshot.length) return null;
        return turnSnapshot[snapshotIndex++];
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("=== GameObjectSet ===\n");
        for (int i = 0; i < objects.size(); i++) {
            sb.append("  ").append(objects.get(i)).append("\n");
        }
        return sb.toString();
    }
}