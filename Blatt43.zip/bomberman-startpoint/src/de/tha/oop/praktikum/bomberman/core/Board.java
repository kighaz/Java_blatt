package de.tha.oop.praktikum.bomberman.core;

import de.tha.oop.praktikum.bomberman.gameobjects.*;
import de.tha.oop.praktikum.bomberman.level.LevelGenerator;
import de.tha.oop.praktikum.bomberman.util.MoveCommand;
import de.tha.oop.praktikum.bomberman.util.XY;

import java.util.ArrayList;
import java.util.List;

public class Board {

    private final GameObjectSet gameObjects;
    private final InteractionGrid interactionGrid;

    public Board(LevelGenerator generator, boolean generatePlayer) {
        this.gameObjects = generator.generate();
        if (generatePlayer) {
            generator.addPlayer(gameObjects);
        }
        this.interactionGrid = new InteractionGrid(generator.getSize(), gameObjects);
        interactionGrid.rebuildGrid();
    }

    public Board(XY fieldSize, GameObjectSet gameObjects) {
        this.gameObjects = gameObjects;
        this.interactionGrid = new InteractionGrid(fieldSize, gameObjects);
        interactionGrid.rebuildGrid();
    }

    public void setPlayerMove(MoveCommand move) {
        for (int i = 0; i < gameObjects.size(); i++) {
            GameObject obj = gameObjects.get(i);
            if (obj instanceof Bomberman && obj.getController() != null) {
                obj.getController().setPlayerMoveCommand(move);
            }
        }
    }

    public void executeTurn() {
        // Snapshot blasts and bombs BEFORE this turn starts
        // so newly created ones (from explosions) are NOT processed this turn
        List<Blast> blastsThisTurn = new ArrayList<>();
        for (int i = 0; i < gameObjects.size(); i++) {
            if (gameObjects.get(i) instanceof Blast bl) blastsThisTurn.add(bl);
        }
        List<Bomb> bombsThisTurn = new ArrayList<>();
        for (int i = 0; i < gameObjects.size(); i++) {
            if (gameObjects.get(i) instanceof Bomb b) bombsThisTurn.add(b);
        }

        // 1. Move all game objects
        gameObjects.startTurn();
        GameObject obj;
        while ((obj = gameObjects.getNextGameObject()) != null) {
            MoveCommand cmd = obj.nextStep(interactionGrid);
            interactionGrid.moveObject(obj, cmd);
        }

        // 2. Tick bombs (only those that existed at start of turn)
        for (Bomb bomb : bombsThisTurn) {
            interactionGrid.processBomb(bomb);
        }

        // 3. Tick blasts (only those that existed at start of turn)
        for (Blast blast : blastsThisTurn) {
            interactionGrid.processBlast(blast);
        }

        gameObjects.endTurn();
    }

    public InteractionGrid getInteractionGrid() { return interactionGrid; }
    public GameObjectSet getGameObjects() { return gameObjects; }
}