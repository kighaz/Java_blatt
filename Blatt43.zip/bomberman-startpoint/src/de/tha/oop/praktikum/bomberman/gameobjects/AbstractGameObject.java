package de.tha.oop.praktikum.bomberman.gameobjects;

import de.tha.oop.praktikum.bomberman.controllers.GameObjectController;
import de.tha.oop.praktikum.bomberman.controllers.StandStillController;
import de.tha.oop.praktikum.bomberman.core.BoardView;
import de.tha.oop.praktikum.bomberman.util.MoveCommand;
import de.tha.oop.praktikum.bomberman.util.XY;

public abstract class AbstractGameObject implements GameObject {

    private static int nextId = 1;

    private final int id;
    private int points;
    private XY location;
    protected GameObjectController controller;

    public AbstractGameObject(GameObjectController controller, XY location) {
        this.id = nextId++;
        this.controller = controller;
        this.location = location;
        this.points = getDefaultPoints();
    }

    public AbstractGameObject(XY location) {
        this(new StandStillController(), location);
    }

    protected abstract int getDefaultPoints();

    @Override
    public GameObjectController getController() {
        return controller;
    }

    @Override
    public int getID() { return id; }

    @Override
    public int getPoints() { return points; }

    @Override
    public void updatePoints(int amount) { this.points += amount; }

    @Override
    public XY getLocation() { return location; }

    @Override
    public void updateLocation(XY loc) { this.location = loc; }

    @Override
    public MoveCommand nextStep(BoardView view) {
        return controller.getNextMove(view);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof AbstractGameObject)) return false;
        return this.id == ((AbstractGameObject) obj).id;
    }

    @Override
    public int hashCode() { return Integer.hashCode(id); }

    @Override
    public String toString() {
        return getClass().getSimpleName() +
                "[id=" + id + ", pos=" + location + ", points=" + points + "]";
    }
}
