package de.tha.oop.praktikum.bomberman.gameobjects;

import de.tha.oop.praktikum.bomberman.controllers.GameObjectController;
import de.tha.oop.praktikum.bomberman.controllers.StandStillController;
import de.tha.oop.praktikum.bomberman.util.XY;

public class DestructibleWall extends AbstractGameObject {

    public static final int DEFAULT_POINTS = 100;

    public DestructibleWall(GameObjectController controller, XY location) {
        super(controller, location);
    }

    public DestructibleWall(XY location) {
        super(new StandStillController(), location);
    }

    @Override
    protected int getDefaultPoints() {
        return DEFAULT_POINTS;
    }
}
