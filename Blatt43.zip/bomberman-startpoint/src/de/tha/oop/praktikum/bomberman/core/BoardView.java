package de.tha.oop.praktikum.bomberman.core;

import de.tha.oop.praktikum.bomberman.gameobjects.GameObject;
import de.tha.oop.praktikum.bomberman.util.XY;

public interface BoardView {
    GameObject getGameObject(int x, int y);
    GameObject getGameObject(XY xy);
    XY getSize();
}
