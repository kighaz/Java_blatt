package de.tha.oop.praktikum.bomberman.controllers;

import de.tha.oop.praktikum.bomberman.core.BoardView;
import de.tha.oop.praktikum.bomberman.util.MoveCommand;

import java.util.Random;

public class RandomController implements GameObjectController {

    private static final MoveCommand[] MOVES = {
        MoveCommand.UP, MoveCommand.DOWN, MoveCommand.LEFT, MoveCommand.RIGHT, MoveCommand.NONE
    };
    private final Random random = new Random();

    @Override
    public MoveCommand getNextMove(BoardView view) {
        return MOVES[random.nextInt(MOVES.length)];
    }
}
