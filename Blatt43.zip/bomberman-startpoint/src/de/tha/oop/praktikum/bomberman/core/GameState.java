package de.tha.oop.praktikum.bomberman.core;

public class GameState {

    private final Board board;
    private int highScore;

    public GameState(Board board) {
        this.board = board;
        this.highScore = 0;
    }

    public void update() {
        board.executeTurn();
    }

    public Board getBoard() {
        return board;
    }

    public int getHighScore() {
        return highScore;
    }

    public void setHighScore(int highScore) {
        this.highScore = highScore;
    }
}
