package de.tha.oop.praktikum.bomberman.core;

import de.tha.oop.praktikum.bomberman.ui.ConsoleUI;
import de.tha.oop.praktikum.bomberman.ui.UI;
import de.tha.oop.praktikum.bomberman.util.MoveCommand;

public class SinglePlayerGame extends Game {

    public SinglePlayerGame(GameState state, UI ui) {
        super(state, ui);
    }

    @Override
    protected void processInput() {
        MoveCommand cmd = ui.getCommand();
        state.getBoard().setPlayerMove(cmd);
    }
}
