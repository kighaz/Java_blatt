package de.tha.oop.praktikum.bomberman.core;

import de.tha.oop.praktikum.bomberman.gameobjects.*;
import de.tha.oop.praktikum.bomberman.util.MoveCommand;
import de.tha.oop.praktikum.bomberman.util.XY;

public class InteractionGrid implements BoardView {

    private final XY size;
    private final GameObjectSet gameObjects;
    private GameObject[][] grid;

    public InteractionGrid(XY size, GameObjectSet gameObjects) {
        this.size = size;
        this.gameObjects = gameObjects;
        rebuildGrid();
    }

    public void rebuildGrid() {
        grid = new GameObject[size.getX()][size.getY()];
        for (int i = 0; i < gameObjects.size(); i++) {
            GameObject obj = gameObjects.get(i);
            XY pos = obj.getLocation();
            if (inBounds(pos)) {
                grid[pos.getX()][pos.getY()] = obj;
            }
        }
    }

    public void moveObject(GameObject object, MoveCommand command) {
        if (!isMovementCommand(command)) return;

        XY current = object.getLocation();
        XY direction = toDirection(command);
        XY target = current.move(direction);

        if (!inBounds(target)) return;
        if (grid[target.getX()][target.getY()] != null) return;

        // Bomberman: si bombe en attente, la poser sur l'ancienne position
        if (object instanceof Bomberman bm && bm.isBombPending()) {
            grid[current.getX()][current.getY()] = null;
            grid[target.getX()][target.getY()] = bm;
            bm.updateLocation(target);

            // Poser la bombe sur l'ancienne position avec owner
            Bomb bomb = new Bomb(current, bm);
            gameObjects.addObject(bomb);
            grid[current.getX()][current.getY()] = bomb;
            bm.clearBombPending();
            return;
        }

        // Mouvement normal
        grid[current.getX()][current.getY()] = null;
        grid[target.getX()][target.getY()] = object;
        object.updateLocation(target);
    }

    public void processBomb(Bomb bomb) {
        if (bomb.tick()) {
            explode(bomb);
        }
    }

    public void processBlast(Blast blast) {
        if (blast.tick()) {
            XY pos = blast.getLocation();
            if (inBounds(pos) && grid[pos.getX()][pos.getY()] == blast) {
                grid[pos.getX()][pos.getY()] = null;
            }
            gameObjects.removeObject(blast);
        }
    }

    private void explode(Bomb bomb) {
        XY center = bomb.getLocation();
        Bomberman owner = bomb.getOwner();

        // Bombe entfernen
        if (inBounds(center)) grid[center.getX()][center.getY()] = null;
        gameObjects.removeObject(bomb);

        // Bomberman benachrichtigen
        for (int i = 0; i < gameObjects.size(); i++) {
            if (gameObjects.get(i) instanceof Bomberman bm) {
                bm.onBombExploded();
            }
        }

        // Explosion in 4 Richtungen
        int[][] dirs = {{0, -1}, {0, 1}, {-1, 0}, {1, 0}};
        for (int[] d : dirs) {
            for (int step = 1; step <= Bomb.BLAST_RADIUS; step++) {
                XY pos = new XY(center.getX() + d[0] * step, center.getY() + d[1] * step);
                if (!inBounds(pos)) break;

                GameObject existing = grid[pos.getX()][pos.getY()];
                if (existing == null) {
                    Blast blast = new Blast(pos, owner);
                    gameObjects.addObject(blast);
                    grid[pos.getX()][pos.getY()] = blast;
                } else if (existing instanceof Monster) {
                    gameObjects.removeObject(existing);
                    Blast blast = new Blast(pos, owner);
                    gameObjects.addObject(blast);
                    grid[pos.getX()][pos.getY()] = blast;
                } else if (existing instanceof DestructibleWall) {
                    gameObjects.removeObject(existing);
                    Blast blast = new Blast(pos, owner);
                    gameObjects.addObject(blast);
                    grid[pos.getX()][pos.getY()] = blast;
                    break; // stop propagation
                } else {
                    break; // Wall, Bomberman, etc: stop, no blast
                }
            }
        }
    }

    private boolean isMovementCommand(MoveCommand cmd) {
        return cmd == MoveCommand.UP || cmd == MoveCommand.DOWN
                || cmd == MoveCommand.LEFT || cmd == MoveCommand.RIGHT;
    }

    private XY toDirection(MoveCommand command) {
        return switch (command) {
            case UP    -> new XY(0, -1);
            case DOWN  -> new XY(0,  1);
            case LEFT  -> new XY(-1, 0);
            case RIGHT -> new XY(1,  0);
            default    -> null;
        };
    }

    private boolean inBounds(XY pos) {
        return pos.getX() >= 0 && pos.getX() < size.getX()
                && pos.getY() >= 0 && pos.getY() < size.getY();
    }

    @Override
    public GameObject getGameObject(int x, int y) {
        if (x < 0 || x >= size.getX() || y < 0 || y >= size.getY()) return null;
        return grid[x][y];
    }

    @Override
    public GameObject getGameObject(XY xy) {
        return getGameObject(xy.getX(), xy.getY());
    }

    @Override
    public XY getSize() { return size; }
}