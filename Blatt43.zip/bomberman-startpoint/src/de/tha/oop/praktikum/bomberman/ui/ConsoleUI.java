package de.tha.oop.praktikum.bomberman.ui;

import de.tha.oop.praktikum.bomberman.core.BoardView;
import de.tha.oop.praktikum.bomberman.gameobjects.GameObject;
import de.tha.oop.praktikum.bomberman.util.MoveCommand;
import de.tha.oop.praktikum.bomberman.util.XY;

import java.util.Scanner;

public class ConsoleUI implements UI {

    private final Scanner scanner = new Scanner(System.in);

    @Override
    public MoveCommand getCommand() {
        System.out.print("Eingabe (W=UP, S=DOWN, A=LEFT, D=RIGHT, B=BOMB, ENTER=NONE): ");
        String input = scanner.nextLine().trim().toUpperCase();
        return switch (input) {
            case "W" -> MoveCommand.UP;
            case "S" -> MoveCommand.DOWN;
            case "A" -> MoveCommand.LEFT;
            case "D" -> MoveCommand.RIGHT;
            case "B" -> MoveCommand.BOMB;
            default  -> MoveCommand.NONE;
        };
    }

    @Override
    public void render(BoardView view) {
        XY size = view.getSize();
        StringBuilder sb = new StringBuilder();
        sb.append("\n");
        // Top border
        sb.append("+");
        for (int x = 0; x < size.getX(); x++) sb.append("--");
        sb.append("+\n");

        for (int y = 0; y < size.getY(); y++) {
            sb.append("|");
            for (int x = 0; x < size.getX(); x++) {
                GameObject obj = view.getGameObject(x, y);
                sb.append(toSymbol(obj)).append(" ");
            }
            sb.append("|\n");
        }

        // Bottom border
        sb.append("+");
        for (int x = 0; x < size.getX(); x++) sb.append("--");
        sb.append("+\n");

        System.out.print(sb);
    }

    private String toSymbol(GameObject obj) {
        if (obj == null) return ".";
        return switch (obj.getClass().getSimpleName()) {
            case "Bomberman"      -> "B";
            case "Monster"        -> "M";
            case "Wall"           -> "#";
            case "DestructibleWall" -> "*";
            case "Bomb"           -> "O";
            case "Blast"          -> "X";
            case "PowerUp"        -> "P";
            default               -> "?";
        };
    }
}
