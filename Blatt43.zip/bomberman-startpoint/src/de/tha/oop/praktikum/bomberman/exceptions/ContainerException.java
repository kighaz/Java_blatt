package de.tha.oop.praktikum.bomberman.exceptions;

/**
 * Ungeprüfte (unchecked) Exception für Container-Fehler.
 * Unchecked, weil Container-Fehler Programmierfehler darstellen,
 * die der Aufrufer nicht sinnvoll abfangen kann (ähnlich wie IndexOutOfBoundsException).
 */
public class ContainerException extends RuntimeException {

    public ContainerException(String message) {
        super(message);
    }

    public ContainerException(String message, Throwable cause) {
        super(message, cause);
    }
}
