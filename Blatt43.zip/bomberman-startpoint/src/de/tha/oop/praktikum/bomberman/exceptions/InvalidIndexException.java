package de.tha.oop.praktikum.bomberman.exceptions;

/**
 * Wird geworfen, wenn ein illegaler Index an die get()-Methode übergeben wird.
 */
public class InvalidIndexException extends ContainerException {

    public InvalidIndexException(int index, int size) {
        super("Invalid index: " + index + " (container size: " + size + ")");
    }
}
