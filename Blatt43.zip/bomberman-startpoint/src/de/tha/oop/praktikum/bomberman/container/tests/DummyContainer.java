package de.tha.oop.praktikum.bomberman.container.tests;

import java.util.ArrayList;
import java.util.Iterator;

import de.tha.oop.praktikum.bomberman.container.Container;


public class DummyContainer implements Container {
	private java.util.List<Object> arrayList = new ArrayList<>();
	
	@Override
	public boolean add(Object o) {
		return arrayList.add(o);
	}

	@Override
	public Object get(int i) {
		return arrayList.get(i);
	}

	@Override
	public int size() {
		return arrayList.size();
	}

	@Override
	public boolean remove(Object o) {
		return arrayList.remove(o);
	}

	@Override
	public Iterator<Object> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterator<Object> iteratorRandom() {
		// TODO Auto-generated method stub
		return null;
	}
}
