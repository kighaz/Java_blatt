package de.tha.oop.praktikum.bomberman.gameobjects;

import de.tha.oop.praktikum.bomberman.controllers.GameObjectController;
import de.tha.oop.praktikum.bomberman.controllers.StandStillController;
import de.tha.oop.praktikum.bomberman.core.BoardView;
import de.tha.oop.praktikum.bomberman.util.MoveCommand;
import de.tha.oop.praktikum.bomberman.util.XY;

public class Bomb extends AbstractGameObject {

    public static final int DEFAULT_POINTS = 300;
    public static final int FUSE_ROUNDS = 5;
    public static final int BLAST_RADIUS = 2;

    private int roundsLeft;
    private final Bomberman owner;

    public Bomb(GameObjectController controller, XY location) {
        super(controller, location);
        this.roundsLeft = FUSE_ROUNDS;
        this.owner = null;
    }

    public Bomb(XY location) {
        super(new StandStillController(), location);
        this.roundsLeft = FUSE_ROUNDS;
        this.owner = null;
    }

    /** Constructor with owner - new Bomb(XY, Bomberman) */
    public Bomb(XY location, Bomberman owner) {
        super(new StandStillController(), location);
        this.roundsLeft = FUSE_ROUNDS;
        this.owner = owner;
    }

    public Bomberman getOwner() { return owner; }

    @Override
    protected int getDefaultPoints() { return DEFAULT_POINTS; }

    public int getRoundsLeft() { return roundsLeft; }

    public boolean tick() {
        roundsLeft--;
        return roundsLeft <= 0;
    }

    @Override
    public MoveCommand nextStep(BoardView view) {
        return MoveCommand.NONE;
    }
}