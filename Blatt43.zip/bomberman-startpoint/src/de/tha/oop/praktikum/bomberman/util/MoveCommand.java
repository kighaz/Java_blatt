package de.tha.oop.praktikum.bomberman.util;

public enum MoveCommand {
    NONE,
    UP,
    DOWN,
    LEFT,
    RIGHT,
    BOMB,
    EXPLODE
}
