package de.tha.oop.praktikum.bomberman.container.tests;
import de.tha.oop.praktikum.bomberman.container.*;

public class ContainerTest {
	 public static void testContainer(Container container) {
		 // add() - Elemente hinzufügen
		 
		 System.out.print("Test1: add()");
		 
		 boolean r1 = container.add("python");
		 boolean r2 = container.add("java");
		 boolean r3 = container.add("C++");
		 System.out.println("add(Python) erwartet [true]: " + r1);
	        System.out.println("add(Java)   erwartet [true]: " + r2);
	        System.out.println("add(C++)    erwartet [true]: " + r3);
	        System.out.println("size()      erwartet [3]:    " + container.size());
		 System.out.print("add(Python) erwartet [true]:" + r1);
		 // --- Test 2: get() ---
	        System.out.println("\n--- Test 2: get() ---");
	        System.out.println("get(0) erwartet [Python]: " + container.get(0));
	        System.out.println("get(1) erwartet [Java]:   " + container.get(1));

	        // --- Test 3: isEmpty() und size() ---
	        System.out.println("\n--- Test 3: isEmpty() und size() ---");
	        System.out.println("isEmpty() erwartet [false]: " + container.isEmpty());
	        System.out.println("size()    erwartet [3]:     " + container.size());

	        // --- Test 4: contains() ---
	        System.out.println("\n--- Test 4: contains() ---");
	        System.out.println("contains(Java)  erwartet [true]:  " + container.contains("Java"));
	        System.out.println("contains(Rust)  erwartet [false]: " + container.contains("Rust"));

	        // --- Test 5: remove() ---
	        System.out.println("\n--- Test 5: remove() ---");
	        boolean removed = container.remove("Java");
	        System.out.println("remove(Java)  erwartet [true]:  " + removed);
	        System.out.println("size()        erwartet [2]:     " + container.size());

	        // --- Test 6: toString() ---
	        System.out.println("\n--- Test 6: toString() ---");
	        System.out.println(container.toString());

	        // --- Test 7: clear() ---
	        System.out.println("\n--- Test 7: clear() ---");
	        container.clear();
	        System.out.println("isEmpty() nach clear() erwartet [true]: " + container.isEmpty());
	    }

	    public static void main(String[] args) {
	        ContainerTest test = new ContainerTest(); // ← Objekt erstellen!
	        
	        System.out.println("===== DummyContainer =====");
	        test.testContainer(new DummyContainer()); // ← Objekt übergeben!
	        
	        System.out.println("===== Vector =====");
	        testContainer(new Vector());
	        System.out.println("===== DoubleLinkedList =====");
	        testContainer(new DoubleLinkedList());
	    }
	}
		 
		 
		 
	
	 
		
		 




	 
