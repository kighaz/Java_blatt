package de.tha.oop.praktikum.bomberman.container;

import java.util.Iterator;

public interface Container extends Iterable<Object> {

    boolean add(Object o);
    Object get(int i);
    int size();
    boolean remove(Object o);
    boolean equals(Object o);

    default void clear() {
        while (size() > 0) {
            remove(get(0));
        }
    }

    default boolean contains(Object o) {
        for (int i = 0; i != size(); ++i) {
            if (o.equals(get(i))) return true;
        }
        return false;
    }

    default Object[] toArray() {
        Object[] ret = new Object[size()];
        for (int i = 0; i != size(); ++i) {
            ret[i] = get(i);
        }
        return ret;
    }

    default boolean isEmpty() {
        return size() == 0;
    }

    /** Gibt einen Iterator zurück, der den Container in zufälliger Reihenfolge iteriert. */
    Iterator<Object> iteratorRandom();
}