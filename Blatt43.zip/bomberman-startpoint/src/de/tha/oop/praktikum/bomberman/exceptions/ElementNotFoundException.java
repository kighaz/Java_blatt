package de.tha.oop.praktikum.bomberman.exceptions;

/**
 * Wird geworfen, wenn ein Objekt aus dem Container entfernt werden soll,
 * das nicht im Container enthalten ist.
 */
public class ElementNotFoundException extends ContainerException {

    public ElementNotFoundException(Object element) {
        super("Element not found in container: " + element);
    }
}
