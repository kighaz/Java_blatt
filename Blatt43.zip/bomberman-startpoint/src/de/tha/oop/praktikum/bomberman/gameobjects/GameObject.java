package de.tha.oop.praktikum.bomberman.gameobjects;

import de.tha.oop.praktikum.bomberman.controllers.GameObjectController;
import de.tha.oop.praktikum.bomberman.core.BoardView;
import de.tha.oop.praktikum.bomberman.util.MoveCommand;
import de.tha.oop.praktikum.bomberman.util.XY;

public interface GameObject {
    XY getLocation();
    void updateLocation(XY loc);
    void updatePoints(int amount);
    int getID();
    int getPoints();

    /** Gibt den Controller der Spielfigur zurück. Default: null. */
    default GameObjectController getController() {
        return null;
    }

    MoveCommand nextStep(BoardView view);
}
