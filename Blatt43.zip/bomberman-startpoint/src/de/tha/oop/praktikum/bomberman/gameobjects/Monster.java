package de.tha.oop.praktikum.bomberman.gameobjects;

import de.tha.oop.praktikum.bomberman.controllers.GameObjectController;
import de.tha.oop.praktikum.bomberman.controllers.RandomController;
import de.tha.oop.praktikum.bomberman.util.XY;

public class Monster extends AbstractGameObject {

    public static final int DEFAULT_POINTS = 300;

    public Monster(GameObjectController controller, XY location) {
        super(controller, location);
    }

    public Monster(XY location) {
        super(new RandomController(), location);
    }

    @Override
    protected int getDefaultPoints() {
        return DEFAULT_POINTS;
    }
}
